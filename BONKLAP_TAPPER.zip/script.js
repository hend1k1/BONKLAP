
let score = 0;
const scoreDisplay = document.getElementById("score");
const button = document.getElementById("tapButton");

const bonkSound = new Audio("bonk.mp3");

button.addEventListener("click", () => {
  score++;
  scoreDisplay.textContent = "Score: " + score;
  bonkSound.currentTime = 0;
  bonkSound.play();
});
