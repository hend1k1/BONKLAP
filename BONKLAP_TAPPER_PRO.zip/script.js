
let score = 0;
let timeLeft = 30;
let timer;
const tapButton = document.getElementById("tapButton");
const resetButton = document.getElementById("resetButton");
const dog = document.getElementById("dog");
const scoreDisplay = document.getElementById("score");
const timerDisplay = document.getElementById("timer");
const leaderboard = document.getElementById("leaderboard");
const bonkSound = new Audio("bonk.mp3");

function updateLeaderboard(name, score) {
  const scores = JSON.parse(localStorage.getItem("bonkScores") || "[]");
  scores.push({ name, score });
  scores.sort((a, b) => b.score - a.score);
  localStorage.setItem("bonkScores", JSON.stringify(scores.slice(0, 5)));
  renderLeaderboard();
}

function renderLeaderboard() {
  const scores = JSON.parse(localStorage.getItem("bonkScores") || "[]");
  leaderboard.innerHTML = "";
  scores.forEach((entry, index) => {
    const li = document.createElement("li");
    li.textContent = `${entry.name}: ${entry.score}`;
    leaderboard.appendChild(li);
  });
}

function startGame() {
  score = 0;
  timeLeft = 30;
  scoreDisplay.textContent = "Score: 0";
  timerDisplay.textContent = "Time Left: 30s";
  clearInterval(timer);
  timer = setInterval(() => {
    timeLeft--;
    timerDisplay.textContent = "Time Left: " + timeLeft + "s";
    if (timeLeft <= 0) {
      clearInterval(timer);
      const name = prompt("Enter your name for the leaderboard:") || "Anonymous";
      updateLeaderboard(name, score);
    }
  }, 1000);
}

tapButton.addEventListener("click", () => {
  if (timeLeft <= 0) return;
  score++;
  scoreDisplay.textContent = "Score: " + score;
  bonkSound.currentTime = 0;
  bonkSound.play();
  dog.classList.add("active");
  setTimeout(() => dog.classList.remove("active"), 100);
});

resetButton.addEventListener("click", startGame);

renderLeaderboard();
startGame();
